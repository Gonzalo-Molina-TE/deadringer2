**Project Description**
A fork of the Duplicate Images Finder project (http://www.codeplex.com/DupliFinder), except the goal of this project is to explore more advanced algorithms and possibly video and audio.

The impetus for this project is Oregon State's [ECE477](http://web.engr.oregonstate.edu/~benl/Courses/ECE477_sp09.html) class on multimedia.  Our home page can be found [here](http://web.engr.oregonstate.edu/~noringj).

The original project has some great things going for it: a nice thread pool implementation that loads all CPUs with work, a simple algorithm for computing similarity, and a clean UI.  But there's always room for improvement.  :)

So far, we've:

* committed a number of bug fixes,
* added support for more image formats and extensions,
* made numerous performance improvements to the original algorithm, resulting in a vast improvement in performance (from about 12 seconds to 200 milliseconds for our test database of images),
* done some work to eventually make the application cross-platform compatible
* implemented totally new algorithms, including SSIM, which seems to provide much more robust results than any other algorithm tried thus far (certainly much better than the default algorithm or any error-based algorithm, like MSE/PSNR)

We have big hopes for this project; more to follow.